# Border Radius

| Token | Value | Default usage |
|---|---|---|
| base | 4px | Cards, inputs, modals, sections — minimal rounding for a sharp sci-fi aesthetic |
| default | 2px | Badges, tooltips, dropdown items, small controls |
| sm | 0px | Checkboxes, tiny elements — fully sharp corners |
| full | 9999px | Pills, avatars, toggles, dot indicators |

## Cut Corner (Chamfer) System

Buttons and select interactive elements use clip-path chamfered corners instead of border-radius. This creates the signature angled/cut look of the cosmic design.

| Context | Corner cut size |
|---|---|
| Buttons (base) | 10px |
| Buttons (small) | 8px |
| Buttons (large) | 12px |
| Cards (optional) | 8px chamfer or 4px radius |
| Hero elements | 14px chamfer |

## Rules

- 4px is the default border-radius across the product for a sharp, technical look
- Buttons use clip-path chamfers instead of border-radius (see `buttons.md`)
- Never use arbitrary radius values outside this scale
- Radius must be consistent within each component family
- Prefer sharp, minimal rounding — the cosmic aesthetic is angular, not soft
