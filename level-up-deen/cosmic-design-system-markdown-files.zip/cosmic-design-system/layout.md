# Layout & Spacing

## Spacing Rhythm

Base unit: **8px**. All spacing values should be multiples of 8px.

| Context | Value |
|---|---|
| Section vertical padding | 96px |
| Section header → content | 48px or 64px |
| Heading → paragraph | 16px |
| Container horizontal padding | 24px |
| Flex/grid row gap | 16px |
| Card grid gap | 24px |
| Wide component grid gap | 32px |
| Column layout gap | 48px |

## Container

Standard section container: max-width 1152px, centered, 24px horizontal padding.

Every major section wraps content in this container.

## Content Composition Order

Inside each section, follow this order:
1. Heading (`h1`–`h3`)
2. Leading paragraph
3. Normal paragraph(s)
4. Lists, CTA links, or component grids

## Section Pattern

Each section has:
- 96px vertical padding
- Background: neutral-primary-soft (#040B17) — ALL sections use the same base color, never alternate
- A subtle linear gradient overlay from neutral-primary (#040B17) to neutral-primary-medium (#071420) for depth
- A centered container (max-width 1152px, 24px horizontal padding)
- A section header area with 48px bottom margin
- Section content below

## Motion & Animation

- Prefer CSS-native: `transition`, `animation`, `@keyframes`. Use Motion library only when CSS cannot achieve the behavior.
- Prioritize high-impact orchestrated moments over scattered micro-interactions. A single well-sequenced page-load animation using staggered `animation-delay` delivers more perceived quality than many isolated effects.
- Reserve scroll-triggered and hover transitions for moments that reinforce hierarchy or reward attention.
- Default transition timing: 300ms ease for interactive elements (buttons, cards, links)
- Hover effects should feel responsive but smooth — never instant, never sluggish
- Consider subtle glow pulsing animations on key interactive elements at rest

## Backgrounds & Visual Depth

- All sections use the same base background: neutral-primary-soft (#040B17)
- Depth is created through subtle gradients (linear-gradient from #040B17 to #071420), not through alternating solid colors
- Apply contextual treatments — gradient meshes, noise textures, geometric grid patterns, layered transparencies, dramatic glow shadows, fine-line decorative borders, grain overlays — that align with the cosmic sci-fi aesthetic
- Glassy/translucent card surfaces (backdrop-filter: blur + low-opacity backgrounds) create depth without introducing new background colors
- Every decorative element must serve a compositional purpose (depth, separation, or emphasis). No purely ornamental effects competing with content.

## Grid-Line Background Pattern

Apply a geometric grid overlay to hero sections and other key areas for the sci-fi "digital" feel:

- **Implementation:** a full-size absolutely-positioned `<div>` covering the section with `pointer-events: none`
- **Horizontal lines:** `linear-gradient(rgba(10,28,46,0.15) 1px, transparent 1px)`
- **Vertical lines:** `linear-gradient(90deg, rgba(10,28,46,0.15) 1px, transparent 1px)`
- **Grid size:** `background-size: 64px 64px`
- **Opacity:** the lines use border-default (#0A1C2E) at 15% opacity — visible enough to add texture, subtle enough not to compete with content
- Use on: hero sections, CTA sections. Not needed on every section.

## Radial Glow Orbs

Large soft radial gradients placed behind content to create ambient depth:

- **Size:** 600–800px diameter circle
- **Color:** `radial-gradient(circle, rgba(26,80,128,0.15-0.18) 0%, transparent 70%)` — using fg-brand color at very low opacity
- **Position:** centered behind hero headings, CTA sections, or other focal points
- **Animation:** optional slow pulse: opacity oscillates between 0.3 and 0.7 over ~5s (`animation: subtleGlow 5s ease-in-out infinite`)
- **Z-index:** behind content, `pointer-events: none`

## Horizontal Glow Line

A thin luminous line that runs horizontally across a section for dramatic effect:

- **Height:** 1px
- **Background:** `linear-gradient(90deg, transparent, rgba(26,80,128,0.3) 30%, rgba(38,112,173,0.5) 50%, rgba(26,80,128,0.3) 70%, transparent)`
- **Position:** absolute, spanning full width at ~55% vertical position in the hero
- Use sparingly — one per hero or CTA section at most.

## Section Separator Lines

Thin gradient lines at section boundaries to visually separate without alternating backgrounds:

- **Height:** 1px
- **Background:** `linear-gradient(90deg, transparent, #0A1C2E 30%, #123650 50%, #0A1C2E 70%, transparent)`
- **Position:** absolute, top: 0 of a section (marks the start of a new section)
- Apply to feature sections, pricing sections — wherever a clean transition is needed.

## Star Field

Twinkling point-lights scattered across hero/CTA sections for a living cosmic night-sky:

- **Implementation:** absolutely-positioned child `<div>`s inside a container with `position: absolute; inset: 0; pointer-events: none`
- **Each star:** a small circle (1–2px width/height), `border-radius: 50%`
- **Color:** `rgba(38,112,173,0.8)` with a matching `box-shadow: 0 0 Npx rgba(38,112,173,0.4)` where N = star size × 3
- **Count:** 15–20 stars per section, randomly scattered with varied positions
- **Animation:** `twinkle` keyframe — opacity fades 0 → 1 → 0, duration 2.5–4.5s, each star gets a unique `animation-delay` for organic stagger
- **Z-index:** behind content, `pointer-events: none`
- Use on: hero, CTA sections. Not needed on every section.

## Hex Grid Overlay

An SVG hexagonal grid pattern layered on the hero for cyberpunk texture:

- **Implementation:** absolutely-positioned `<svg>` with `width: 100%; height: 100%` filling the section
- **Pattern:** SVG `<pattern>` element with two hexagon `<path>` shapes tiled at 56×100 units, scaled 1.5×
- **Stroke:** `rgba(26,80,128,0.5)` at `stroke-width: 0.5`
- **Container opacity:** 0.04 — extremely subtle, adds texture without competing with content
- **Z-index:** behind content, `pointer-events: none`
- Use on: hero section only. Not needed elsewhere.

## Scanline Overlay

CRT-style horizontal scanlines that scroll slowly for retro-futuristic atmosphere:

- **Implementation:** absolutely-positioned `<div>` covering the section with `overflow: hidden`
- **Lines:** `repeating-linear-gradient(0deg, transparent, transparent 2px, rgba(255,255,255,0.1) 2px, rgba(255,255,255,0.1) 4px)`
- **Container opacity:** 0.03 — barely perceptible, adds subliminal texture
- **Animation:** `scanline` keyframe — `translateY(-100%)` to `translateY(100vh)`, duration ~8s, linear, infinite
- **Z-index:** above background layers but behind content, `pointer-events: none`
- Use on: hero section only.

## Data Streams

Vertical flowing light beams that descend through the hero like digital data transmission:

- **Implementation:** absolutely-positioned `<div>`s inside an overflow-hidden container
- **Each stream:** 1px wide, ~60% of section height
- **Background:** `linear-gradient(180deg, transparent, fg-brand-strong, transparent)`
- **Count:** 5–6 streams at varied horizontal positions
- **Opacity:** 0.04–0.08 per stream — very subtle
- **Animation:** `dataStream` keyframe — translateY from -100% to 100%, duration 5–9s, linear, each stream with unique delay
- **Z-index:** behind content, `pointer-events: none`
- Use on: hero section only.

## Pulse Ring

An expanding/fading ring that pulses outward from the hero center for dramatic depth:

- **Implementation:** absolutely-positioned `<div>` centered in the section
- **Size:** ~600px diameter circle, `border-radius: 50%`
- **Border:** `1px solid rgba(26,80,128,0.15)`
- **Background:** none (border-only ring)
- **Animation:** `pulseRing` keyframe — scales from 0.8 to 1.2 while opacity fades from 0.4 to 0, duration ~4s, ease-out, infinite
- **Z-index:** behind content, `pointer-events: none`
- Use on: hero section center. One per page at most.

## Multi-Orb Composition

Extend the single "Radial Glow Orbs" pattern into a layered multi-orb system for richer depth:

- **Primary orb:** 800px, brand color `rgba(26,80,128,0.2)`, centered top of hero, `orbFloat` animation (8s, translates and scales gently)
- **Secondary orb:** 500px, cyan tint `rgba(6,182,212,0.08)`, offset left at ~30%, `orbFloat2` animation (12s, different movement path)
- **Tertiary orb:** 400px, brand `rgba(38,112,173,0.1)`, offset right, `orbFloat2` animation (10s, 2s delay)
- Each orb uses a unique animation with slightly different translate offsets and scale values to avoid synchronized movement
- All: `pointer-events: none`, behind content

## Corner Accents

Cyberpunk-style decorative corner brackets that frame a section:

- **Implementation:** four small SVGs positioned at each corner of a relatively-positioned container (inset 24–48px from section edges)
- **Each corner:** an L-shaped 2px line + a small filled triangle at 15% opacity
- **Size:** 50–80px per corner piece
- **Color:** border-default-medium (#0D2740) or border-default-strong (#123650)
- **Z-index:** decorative layer, `pointer-events: none`
- Use on: hero section, CTA section. Creates a "targeting reticle" framing effect.

## Animated Glow Lines

Enhanced version of the Horizontal Glow Line with animation:

- **Background:** same gradient as Horizontal Glow Line but with `background-size: 200% 1px`
- **Animation:** `glowLine` keyframe — background-position slides from -100% to 100% while opacity pulses 0.3 → 0.8 → 0.3, duration ~6s, ease-in-out, infinite
- A secondary glow line at ~30% vertical position can use a cyan tint `rgba(6,182,212,0.15)` at 50% opacity for color variety
- Use on: hero section. At most 2 animated lines per section.

## Navigation Bar

Sticky top navigation with a glassy/frosted appearance:

- **Position:** `sticky`, `top: 0`, `z-index: 50`
- **Background:** `rgba(4,11,23,0.9)` (neutral-primary-soft at 90% opacity)
- **Backdrop filter:** `blur(16px)` + `-webkit-backdrop-filter: blur(16px)`
- **Border bottom:** 1px solid border-default (#0A1C2E)
- **Height:** 64px
- **Container:** max-width 1152px centered, 24px horizontal padding
- **Layout:** flex, space-between, vertically centered
- **Left:** logo (brand gradient text or icon + text)
- **Right:** nav links (12-14px, uppercase, letter-spacing 1px, body color, hover → heading color) + CTA button (cut-corner brand button, small size)
- **Mobile:** hamburger menu that reveals nav links in a dropdown panel with the same glassy background

## Must

- All sections: consistent 96px vertical padding
- All sections: same neutral-primary-soft (#040B17) background — no alternating
- All containers: max-width 1152px, centered, 24px horizontal padding
- Section headers: 48px or 64px bottom margin
- Consistent vertical rhythm, no crowded sections
- Layouts readable and properly spaced on both desktop and mobile
- Hero sections: layer grid-line background + hex grid + star field + data streams + scanlines + multi-orb composition + pulse ring + corner accents + animated glow lines for maximum cosmic depth
- CTA sections: use star field + glow orbs + corner accents + glow lines for depth
- Section boundaries: use gradient separator lines where visual breaks are needed
- All decorative overlays: `pointer-events: none`, behind content z-index, opacity kept low enough not to compete with text
