# Color Tokens


## Background Tokens

### Neutral
| Token | Light | Dark |
|---|---|---|
| neutral-primary-soft | #040B17 | #040B17 |
| neutral-primary | #040B17 | #040B17 |
| neutral-primary-medium | #071420 | #071420 |
| neutral-primary-strong | #0C2236 | #0C2236 |
| neutral-secondary-soft | #040B17 | #040B17 |
| neutral-secondary | #040B17 | #040B17 |
| neutral-secondary-medium | #071420 | #071420 |
| neutral-secondary-strong | #0C2236 | #0C2236 |
| neutral-tertiary-soft | #071420 | #071420 |
| neutral-tertiary | #0A1C2E | #0A1C2E |
| neutral-tertiary-medium | #0C2236 | #0C2236 |
| neutral-quaternary | #0F2A42 | #0F2A42 |
| quaternary-medium | #123650 | #123650 |
| gray | #1A4A6A | #1A4A6A |

### Brand
| Token | Light | Dark |
|---|---|---|
| brand-softer | #081620 | #081620 |
| brand-soft | #0A1E30 | #0A1E30 |
| brand | #06121D | #06121D |
| brand-medium | #0A1E30 | #0A1E30 |
| brand-strong | #040E17 | #040E17 |

### Status
| Token | Light | Dark |
|---|---|---|
| success-soft | #021A14 | #021A14 |
| success | #007A55 | #009966 |
| success-medium | #003D2A | #003D2A |
| success-strong | #006045 | #007A55 |
| danger-soft | #2A0010 | #2A0010 |
| danger | #C70036 | #C70036 |
| danger-medium | #550020 | #550020 |
| danger-strong | #A50036 | #A50036 |
| warning-soft | #2A1508 | #2A1508 |
| warning | #F97316 | #F97316 |
| warning-medium | #3A1808 | #3A1808 |
| warning-strong | #C2410C | #C2410C |

### Button Glint (CSS custom properties, used for the glint box-shadow effect)
| Variable | Light | Dark |
|---|---|---|
| `--color-1-400` | rgba(255,255,255,0.06) | rgba(255,255,255,0.06) |
| `--color-1-700` | rgba(6,18,29,0.4) | rgba(6,18,29,0.4) |

### Utility
| Token | Light | Dark |
|---|---|---|
| dark | #040B17 | #040B17 |
| dark-strong | #020710 | #071420 |
| disabled | #071420 | #071420 |

### Accent
| Token | Value (same both modes) |
|---|---|
| purple | #6366F1 |
| sky | #0EA5E9 |
| teal | #0D9488 |
| pink | #DB2777 |
| cyan | #06B6D4 |
| fuchsia | #C026D3 |
| indigo | #4F46E5 |
| orange | #FB923C |

## Text Color Tokens

### Base
| Token | Light | Dark |
|---|---|---|
| white | #FFFFFF | #FFFFFF |
| black | #040B17 | #040B17 |
| heading | #E2E8F0 | #E2E8F0 |
| body | #7A8BA0 | #7A8BA0 |
| body-subtle | #5A6B80 | #5A6B80 |

### Brand
| Token | Light | Dark |
|---|---|---|
| fg-brand-subtle | #0D2A44 | #0D2A44 |
| fg-brand | #1A5080 | #1A5080 |
| fg-brand-strong | #2670AD | #2670AD |

### Status
| Token | Light | Dark |
|---|---|---|
| fg-success | #009966 | #009966 |
| fg-success-strong | #10B981 | #10B981 |
| fg-danger | #F43F5E | #F43F5E |
| fg-danger-strong | #F87171 | #F87171 |
| fg-warning-subtle | #F97316 | #F97316 |
| fg-warning | #FBBF24 | #FBBF24 |
| fg-disabled | #3A4A5A | #3A4A5A |

### Informational / Accent
| Token | Light | Dark |
|---|---|---|
| fg-yellow | #FACC15 | #FACC15 |
| fg-info | #93C5FD | #93C5FD |
| fg-purple | #A855F7 | #A855F7 |
| fg-purple-strong | #DDD6FE | #DDD6FE |
| fg-cyan | #06B6D4 | #06B6D4 |
| fg-indigo | #818CF8 | #818CF8 |
| fg-pink | #F472B6 | #F472B6 |
| fg-lime | #84CC16 | #84CC16 |

## Border Color Tokens

| Token | Light | Dark |
|---|---|---|
| border-dark | #0A1C2E | #0A1C2E |
| border-buffer | #040B17 | #040B17 |
| border-buffer-medium | #071420 | #071420 |
| border-buffer-strong | #0A1C2E | #0A1C2E |
| border-muted | #050D18 | #050D18 |
| border-light-subtle | #061019 | #061019 |
| border-light | #071420 | #071420 |
| border-light-medium | #0A1C2E | #0A1C2E |
| border-default-subtle | #061019 | #061019 |
| border-default | #0A1C2E | #0A1C2E |
| border-default-medium | #0D2740 | #0D2740 |
| border-default-strong | #123650 | #123650 |
| border-success-subtle | #003D2A | #003D2A |
| border-success | #006045 | #006045 |
| border-danger-subtle | #550020 | #550020 |
| border-danger | #C70036 | #C70036 |
| border-warning-subtle | #3A1808 | #3A1808 |
| border-warning | #F97316 | #F97316 |
| border-brand-subtle | #0A1E30 | #0A1E30 |
| border-brand-light | #06121D | #06121D |
| border-brand | #1A5080 | #1A5080 |
| border-dark-subtle | #0A1C2E | #0A1C2E |
| border-purple | #6366F1 | #6366F1 |
| border-orange | #FB923C | #FB923C |

## Semantic Usage Rules

- Page/section backgrounds: neutral-primary-soft (#040B17) — same color for ALL sections, never alternate
- Section depth: use subtle linear gradients from neutral-primary (#040B17) to neutral-primary-medium (#071420) for visual layering
- Primary buttons: brand background with cut-corner clip-path and subtle border glow
- Headings: heading text color (#E2E8F0); h1 elements use a linear gradient from fg-brand (#1A5080) to fg-brand-strong (#2670AD) via background-clip text
- Body text: body text color
- CTA links: fg-brand text color
- Default borders: border-default
- Status borders match intent: success → border-success, danger → border-danger, warning → border-warning
- Disabled: disabled background + fg-disabled text

## Prohibited

- No raw hex/rgb values in component code — always use design tokens
- No brand text color for long-form paragraphs
- No accent text tokens (fg-purple, etc.) for body copy or navigation
- No brand/accent backgrounds for large layout surfaces (pages, sections) unless it's a hero/campaign area
- No manual light/dark value swapping — let the CSS custom properties handle it
- No alternating section background colors — all sections use the same neutral-primary-soft (#040B17) base
