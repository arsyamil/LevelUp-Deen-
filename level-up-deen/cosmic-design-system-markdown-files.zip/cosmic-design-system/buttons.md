# Buttons

> Dependencies: `colors.md`, `radius.md`, `shadows.md`

## Core Specs (every button except ghost and disabled)

- **Shape:** Cut corners via `clip-path: polygon(10px 0, calc(100% - 10px) 0, 100% 10px, 100% calc(100% - 10px), calc(100% - 10px) 100%, 10px 100%, 0 calc(100% - 10px), 0 10px)` — creates chamfered/angled corners instead of rounded
- **Border:** 1px solid — rendered via a **wrapper element** (REQUIRED technique, see "Wrapper Border Technique" below). Standard CSS borders are clipped away by `clip-path`, so borders MUST be implemented using the wrapper approach.
- **Shadow:** Applied to the WRAPPER element (not the inner button, since clip-path clips box-shadows too). shadow-xs combined with a subtle brand glow: `0 0 15px rgba(10,28,46,0.4), 0 0 30px rgba(6,18,29,0.15)`
- **Glint effect:** Every button except ghost and disabled gets a combined box-shadow on the wrapper that layers the base shadow with an inset top-edge highlight and a subtle outer glow:
  - `var(--shadow-xs), inset var(--color-1-400) 0 6px 0px -5px, var(--color-1-700) 0 4px 10px -5px, 0 0 20px rgba(10,28,46,0.4)`
- **Font weight:** 500 (medium)
- **Font:** Audiowide
- **Text transform:** uppercase
- **Letter-spacing:** 1px
- **Box sizing:** border-box
- **Transition:** all 300ms ease — covers background, border-color, box-shadow, transform, and color on hover
- **Hover transform:** translateY(-1px) for subtle lift effect
- **Hover glow:** increase box-shadow glow intensity on hover (e.g. `0 0 20px rgba(6,18,29,0.5), 0 0 40px rgba(6,18,29,0.25)`)

## Cut Corner Implementation

All buttons use a clip-path polygon to create chamfered corners. The cut size scales with button size:

| Size | Corner cut |
|---|---|
| Extra small | 6px |
| Small | 8px |
| Base (default) | 10px |
| Large | 12px |
| Extra large | 14px |

### Wrapper Border Technique (REQUIRED)

`clip-path` clips everything — borders, box-shadows, and outlines are all invisible on a clipped element. The ONLY reliable way to render visible borders on chamfered buttons is the **wrapper technique**:

1. Create an outer wrapper element (`<div>`) with the **same** `clip-path` polygon as the button
2. Set the wrapper's `background` to the **border color** (e.g. border-default-strong #123650 for brand, border-default-medium #0D2740 for secondary)
3. Set the wrapper's `padding: 1px` (this is the border width — the 1px gap between wrapper and inner becomes the visible border)
4. Place the actual button/link inside the wrapper with the **same** `clip-path` and its own background color
5. Apply all box-shadows and the glint effect to the **wrapper**, not the inner button (since clip-path on the inner would clip them)

On hover:
- The wrapper's `background` (border color) brightens (e.g. brand → border-brand #1A5080, secondary → border-default-strong #123650)
- The wrapper's box-shadow glow intensifies
- The wrapper gets `transform: translateY(-1px)` for lift
- The inner button's background shifts to its hover color

This produces a clearly visible glowing chamfered border that is the signature look of this design system. Do NOT skip this — buttons without the wrapper look flat and broken.

## Sizes

| Size | Font size | Horizontal padding | Vertical padding |
|---|---|---|---|
| Extra small | 12px | 12px | 6px |
| Small | 14px | 12px | 8px |
| Base (default) | 14px | 16px | 10px |
| Large | 16px | 20px | 12px |
| Extra large | 16px | 24px | 14px |

## Variants

### Brand
- **Background (inner):** brand token (#06121D)
- **Wrapper border color:** border-default-strong (#123650)
- **Wrapper border color on hover:** border-brand (#1A5080)
- **Text:** heading color (#E2E8F0)
- **Hover (inner):** brand-soft (#0A1E30) background, increased glow shadow on wrapper, wrapper translateY(-1px)
- **Focus ring:** 4px, brand-medium color
- **Glint:** yes (on wrapper)

### Secondary
- **Background (inner):** neutral-secondary-medium (#071420)
- **Wrapper border color:** border-default-medium (#0D2740)
- **Wrapper border color on hover:** border-default-strong (#123650)
- **Text:** body color
- **Hover (inner):** neutral-tertiary-medium (#0C2236) background, heading text color, wrapper translateY(-1px), subtle glow increase on wrapper
- **Focus ring:** 4px, neutral-tertiary color
- **Glint:** yes (on wrapper)

### Tertiary
- **Background:** neutral-primary-soft
- **Border:** border-default
- **Text:** body color
- **Hover:** neutral-secondary-medium background, heading text color, translateY(-1px)
- **Focus ring:** 4px, neutral-tertiary-soft color
- **Glint:** yes

### Success
- **Background:** success token
- **Border:** transparent
- **Text:** white
- **Hover:** success-strong background, translateY(-1px), glow increase
- **Focus ring:** 4px, success-medium color
- **Glint:** yes

### Danger
- **Background:** danger token
- **Border:** transparent
- **Text:** white
- **Hover:** danger-strong background, translateY(-1px), glow increase
- **Focus ring:** 4px, danger-medium color
- **Glint:** yes

### Warning
- **Background:** warning token
- **Border:** transparent
- **Text:** white
- **Hover:** warning-strong background, translateY(-1px), glow increase
- **Focus ring:** 4px, warning-medium color
- **Glint:** yes

### Dark
- **Background:** dark token
- **Border:** transparent
- **Text:** white
- **Hover:** dark-strong background, translateY(-1px), glow increase
- **Focus ring:** 4px, neutral-tertiary color
- **Glint:** yes

### Ghost (NO shadow, NO glint, NO cut corners)
- **Background:** transparent
- **Border:** transparent
- **Text:** heading color
- **Hover:** neutral-secondary-medium background, translateY(-1px)
- **Focus ring:** 4px, neutral-tertiary color
- **No shadow, no glint effect**
- **Uses standard border-radius (base) instead of clip-path**

### Disabled (NO shadow, NO glint)
- **Background:** disabled token
- **Border:** border-default-medium
- **Text:** fg-disabled color
- **Cursor:** not-allowed
- **No hover, no focus, no shadow, no glint**

## Hover Transition Details

All interactive buttons (not disabled) have these hover behaviors:
- **Background:** shifts to the hover variant color (300ms ease)
- **Box-shadow:** glow intensifies (300ms ease)
- **Transform:** translateY(-1px) for a lift effect (300ms ease)
- **Border-color:** may brighten subtly (300ms ease)
- On mouse leave, all properties transition back smoothly

## Icons in Buttons

- Icon size: 16x16px
- Spacing: 8px gap between icon and label
- Layout: inline-flex, vertically centered
