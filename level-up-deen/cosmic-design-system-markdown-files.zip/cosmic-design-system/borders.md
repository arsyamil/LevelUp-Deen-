# Borders

## Width Scale

| Context | Width |
|---|---|
| Default (inputs, buttons, cards) | 1px |
| Emphasis / focus | 2px |

## Rules

- Use solid borders by default
- Border colors should be very subtle against the dark background — prefer border-default (#0A1C2E) or border-default-medium (#0D2740) for most elements
- Dashed borders only for special cases like file dropzones
- Components in the same family must use matching border widths
- Never mix 1px and 2px borders within a single component
- Borders on dark backgrounds create separation through slight luminosity differences, not strong contrast

## Glow Border Effect

For interactive or emphasized elements, borders can have a subtle glow:
- Apply a `box-shadow: 0 0 8px rgba(10,28,46,0.4)` alongside the border for a sci-fi glow effect
- On hover, increase the glow: `box-shadow: 0 0 12px rgba(10,28,46,0.6)`
- Transition: box-shadow 300ms ease

## Usage

| Context | Width |
|---|---|
| Inputs / selects / textareas | 1px default; 2px on focus or error |
| Buttons | 1px for variants that require outlining (rendered via wrapper/pseudo-element around clip-path) |
| Cards / containers | 1px subtle; avoid stacked heavy borders |
