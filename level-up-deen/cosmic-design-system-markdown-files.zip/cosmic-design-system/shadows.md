# Shadows

| Token | CSS value |
|---|---|
| shadow-2xs | `0 1px rgb(0 0 0 / 0.15)` |
| shadow-xs | `0 1px 2px 0 rgb(0 0 0 / 0.2)` |
| shadow-sm | `0 1px 3px 0 rgb(0 0 0 / 0.25), 0 1px 2px -1px rgb(0 0 0 / 0.2)` |
| shadow-md | `0 4px 6px -1px rgb(0 0 0 / 0.3), 0 2px 4px -2px rgb(0 0 0 / 0.25)` |
| shadow-lg | `0 10px 15px -3px rgb(0 0 0 / 0.3), 0 4px 6px -4px rgb(0 0 0 / 0.25)` |
| shadow-xl | `0 20px 25px -5px rgb(0 0 0 / 0.35), 0 8px 10px -6px rgb(0 0 0 / 0.3)` |
| shadow-2xl | `0 25px 50px -12px rgb(0 0 0 / 0.5)` |

## Glow Shadows

For interactive and elevated elements, use glow effects that complement the cosmic dark theme:

| Token | CSS value |
|---|---|
| glow-brand | `0 0 15px rgba(6,18,29,0.3), 0 0 30px rgba(6,18,29,0.15)` |
| glow-brand-hover | `0 0 20px rgba(6,18,29,0.5), 0 0 40px rgba(6,18,29,0.25)` |
| glow-subtle | `0 0 10px rgba(6,18,29,0.2)` |
| glow-border | `0 0 8px rgba(10,28,46,0.4)` |

## Component Mapping

| Component type | Token |
|---|---|
| Subtle separators, tiny UI details | shadow-2xs or shadow-xs |
| Inputs, buttons, small controls, lightweight cards | shadow-xs or shadow-sm + glow-subtle |
| Standard cards, popovers, dropdowns | shadow-md + glow-subtle |
| Prominent cards, sticky surfaces | shadow-lg + glow-brand |
| Modals, high-priority overlays | shadow-xl |
| Hero overlays, top-level emphasis (sparingly) | shadow-2xl + glow-brand |

## Text Glow (filter: drop-shadow)

For gradient-text headings (which use `background-clip: text` + `color: transparent`), traditional `text-shadow` does not work. Use `filter: drop-shadow()` on a **parent wrapper** element:

| Token | CSS value (applied via `filter` on wrapper) |
|---|---|
| text-glow-brand | `drop-shadow(0 0 30px rgba(38,112,173,0.6)) drop-shadow(0 0 60px rgba(26,80,128,0.3))` |
| text-glow-brand-strong | `drop-shadow(0 0 40px rgba(38,112,173,0.7)) drop-shadow(0 0 80px rgba(26,80,128,0.4))` |

Use text-glow-brand on section headings; use text-glow-brand-strong on hero/CTA headings for extra emphasis.

## Rules

- Use only these tokens — no custom box-shadow values except glow combinations
- Keep elevation steps intentional; avoid jumping multiple levels
- Components in the same family share the same baseline elevation
- Hover/focus on interactive elevated elements: step up by one level and increase glow intensity
- Never stack multiple shadow tokens on one element (glow tokens can be combined with one shadow token)
- Never use shadow-xl/shadow-2xl for dense list items or body containers
- On dark backgrounds, shadows are subtle — glow effects provide more visual impact than traditional drop shadows
- Gradient-text glow MUST use `filter: drop-shadow()` on a wrapper, NOT `text-shadow` (which doesn't work with transparent text color)
