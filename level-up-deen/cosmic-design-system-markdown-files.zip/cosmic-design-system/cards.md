# Cards

> Dependencies: `colors.md`, `radius.md`, `shadows.md`, `typography.md`

## Core Specs

- **Background:** neutral-primary-medium (#071420) at 60-80% opacity for a glassy/translucent effect — e.g. `rgba(7,20,32,0.7)`
- **Backdrop filter:** `backdrop-filter: blur(12px)` and `-webkit-backdrop-filter: blur(12px)` for frosted glass appearance
- **Shape:** Cut corners via `clip-path: polygon(12px 0, calc(100% - 12px) 0, 100% 12px, 100% calc(100% - 12px), calc(100% - 12px) 100%, 12px 100%, 0 calc(100% - 12px), 0 12px)` — chamfered/angled corners matching the button aesthetic
- **Border:** 1px solid — rendered via a **wrapper element** (same technique as buttons). Standard CSS borders are clipped away by `clip-path`, so borders MUST be implemented using the wrapper approach.
- **Shadow:** Applied to the WRAPPER element (not the inner card, since clip-path clips box-shadows too). shadow-xs + glow-subtle: `0 1px 2px 0 rgb(0 0 0 / 0.2), 0 0 10px rgba(6,18,29,0.2)`
- **Transition:** `all 300ms ease` on every card

## Card Heading

- Desktop: 20px, medium weight, heading color
- Mobile: 16px, medium weight, heading color
- Never skip heading levels — the page hierarchy must logically arrive at the card heading level.

## States

### Static Card (no interactivity)
- Background: `rgba(7,20,32,0.7)` (neutral-primary-medium at ~70% opacity)
- Backdrop filter: blur(12px)
- Shape: cut corners (same clip-path as Core Specs)
- Border: 1px solid border-default (#0A1C2E) via wrapper technique
- Shadow: `0 1px 2px 0 rgb(0 0 0 / 0.2), 0 0 10px rgba(6,18,29,0.2)` on wrapper
- No hover styles. Non-interactive cards must NOT have hover background changes.

### Interactive Card (clickable / hoverable)
- Same base styles as static card
- **Hover border:** brightens to border-default-medium (#0D2740)
- **Hover background:** opacity increases to ~90%: `rgba(7,20,32,0.9)`
- **Hover shadow:** steps up with stronger glow: `0 4px 6px -1px rgb(0 0 0 / 0.3), 0 2px 4px -2px rgb(0 0 0 / 0.25), 0 0 15px rgba(10,28,46,0.4), 0 0 30px rgba(6,18,29,0.15)`
- Transition: all 300ms ease
- Cursor: pointer

### Highlighted Card (emphasis variant)
Use when one card should stand out in a set (e.g. featured pricing tier):
- **Background:** `rgba(10,30,48,0.8)` — slightly brighter than standard
- **Border:** 1px solid border-default-strong (#123650) — brighter than default
- **Shadow:** shadow-md + glow-brand: `0 4px 6px -1px rgb(0 0 0 / 0.3), 0 2px 4px -2px rgb(0 0 0 / 0.25), 0 0 20px rgba(10,28,46,0.5), 0 0 40px rgba(6,18,29,0.2)`
- **Hover border:** border-brand (#1A5080)
- **Hover shadow:** glow intensifies: `0 0 25px rgba(26,80,128,0.4), 0 0 50px rgba(10,28,46,0.25)`
- **Top accent line (optional):** a 2px-high gradient line across the card top: `linear-gradient(90deg, fg-brand, fg-brand-strong, fg-brand)` positioned `top: -1px, left: -1px, right: -1px`

## Cut Corner Implementation

All cards use a clip-path polygon to create chamfered corners (12px cut), matching the button aesthetic:

```
clip-path: polygon(12px 0, calc(100% - 12px) 0, 100% 12px, 100% calc(100% - 12px), calc(100% - 12px) 100%, 12px 100%, 0 calc(100% - 12px), 0 12px)
```

### Wrapper Border Technique (REQUIRED)

`clip-path` clips everything — borders, box-shadows, and outlines are all invisible on a clipped element. The ONLY reliable way to render visible borders and shadows on chamfered cards is the **wrapper technique** (same as buttons):

1. Create an outer wrapper element (`<div>`) with the **same** `clip-path` polygon as the card
2. Set the wrapper's `background` to the **border color** (e.g. border-default #0A1C2E)
3. Set the wrapper's `padding: 1px` (this is the border width — the 1px gap between wrapper and inner becomes the visible border)
4. Place the actual card content inside the wrapper with the **same** `clip-path` and its own background color
5. Apply all box-shadows to the **wrapper**, not the inner card (since clip-path on the inner would clip them)

On hover (interactive cards):
- The wrapper's `background` (border color) brightens
- The wrapper's box-shadow glow intensifies
- The inner card's background shifts to its hover color

This produces chamfered borders consistent with the button design. Do NOT skip this — cards without the wrapper look flat and broken.

## Rules

- Background: neutral-primary-medium at reduced opacity for glass effect
- Backdrop filter: blur(12px) + -webkit-backdrop-filter: blur(12px)
- Shape: cut corners via clip-path (12px chamfer) — NO border-radius
- Border: 1px via wrapper technique (clip-path clips standard borders)
- Shadow: shadow-xs + glow-subtle, applied to wrapper element
- Interactive hover: increased opacity, brighter border, stronger glow (300ms ease)
- Non-interactive: no hover styles
- Highlighted cards use brighter borders and stronger glows to stand out
