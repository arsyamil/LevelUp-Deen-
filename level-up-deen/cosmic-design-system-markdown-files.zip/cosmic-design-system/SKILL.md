---
name: "cosmic-design-system"
description: "Cosmic Design System design system for AI coding agents."
metadata:
  author: typeui.sh
  source: workspace-importer
  projectName: "levelup-deen"
  projectLogoUrl: ""
  importSource: "Manual TypeUI setup"
  primaryColorReference: "#18181b"
  surfaceColorReference: "#ffffff"
  textColorReference: "#09090b"
  typographyScale: "Inter-style sans serif, 12/14/16/20/24/32 scale, medium labels, semibold headings."
  spacingScale: "4px base grid with 8px, 12px, 16px, 24px, and 32px layout steps."
  radiusScale: "6px controls, 8px cards, 12px overlays, nested radii reduced by inner padding."
---

# Design System — Agent Instructions

This skill describes the visual design language for all UI output. Every component, layout, and page should follow the design specs in the module files below. These describe *what the design looks like* — you choose how to implement the styles.

## Style
A cosmic, sci-fi inspired dark interface featuring deep navy-to-black backgrounds (#040B17), chamfered/cut-corner buttons with visible wrapper-based borders and glow, glassy translucent cards with glowing edges, the Audiowide typeface throughout, uppercase headings with wide letter-spacing, gradient text with luminous drop-shadow glow on key headings, geometric grid-line background textures, radial glow orbs for visual depth, and gradient-line section separators — engineered for a futuristic, high-tech aesthetic.

## Before Writing Any Code

1. **Read every module that applies.** For a landing page, read at minimum: `layout.md`, `typography.md`, `colors.md`, `buttons.md`, `cards.md`, `shadows.md`, `radius.md`, `borders.md`. Do NOT write JSX until you have loaded all relevant modules.

## Critical Rules

- **Tokens are AGNOSTIC, NOT Tailwind classes:** The tokens defined in the `.md` files (like `neutral-primary-soft`, `heading`, `border-default`) are agnostic design system tokens, NOT literal Tailwind classes. Do not blindly use classes like `bg-neutral-primary-soft` unless you have explicitly mapped them in the CSS/Tailwind configuration. You must implement the mapping yourself.

- **Cross-reference modules.** A card containing buttons must satisfy both `cards.md` AND `buttons.md`.
- **Dark mode is automatic.** The CSS custom properties resolve differently in light/dark via `@media (prefers-color-scheme: dark)`. Never manually swap colors.
- **Every interactive element needs hover, focus, and disabled states** — defined in the relevant module.
- **Use semantic HTML:** proper heading hierarchy (`h1`→`h6`), `<button>` for actions, `<a>` for navigation, ARIA attributes where needed.
- **All sections use the same background** — neutral-primary-soft (#040B17). Never alternate section background colors.
- **Buttons use cut corners** (clip-path chamfers), not border-radius. Borders on clipped buttons MUST use a wrapper element technique — the wrapper has the same clip-path, is colored with the border color, and uses 1px padding so the inner button sits inside creating a visible border that follows the chamfered shape. See `buttons.md`.
- **Gradient text with glow** — h1 and emphasis headings use `linear-gradient(135deg, fg-brand, fg-brand-strong)` with `background-clip: text`, PLUS a parent wrapper with `filter: drop-shadow()` to create a luminous glow around the gradient text. See `typography.md`.
- **Grid-line backgrounds** — hero and key sections use a geometric grid overlay (1px lines at ~15% opacity in border-default color, spaced 64px). See `layout.md`.
- **Glow orbs** — large radial-gradient circles in brand colors at low opacity, placed behind hero/CTA content for ambient depth. See `layout.md`.
- **Section separators** — thin horizontal gradient lines (transparent → border-default-strong → transparent) mark transitions between sections. See `layout.md`.
- **Font:** Audiowide (Google Fonts) for all text — headings and body. No secondary font.
- **Navigation bar** — sticky, glassy (backdrop-filter: blur), with logo, nav links, and a cut-corner CTA button. See `layout.md`.

## Module Index

### Foundation (read first for any UI work)
- [colors.md](colors.md) — all background, text, and border color tokens
- [typography.md](typography.md) — heading scale, paragraphs, labels, links
- [layout.md](layout.md) — spacing rhythm, containers, animation, visual depth
- [radius.md](radius.md) — border-radius scale
- [shadows.md](shadows.md) — elevation tokens
- [borders.md](borders.md) — border widths and styles

### Components
- [buttons.md](buttons.md) — button variants, sizes, states, glint effect
- [button-group.md](button-group.md) — grouped button structure
- [cards.md](cards.md) — card structure, background, interactivity
- [inputs.md](inputs.md) — form controls, labels, states
- [alerts.md](alerts.md) — alert variants
- [badges.md](badges.md) — badge variants, sizes, dismissible chips
- [lists.md](lists.md) — list components
- [avatars.md](avatars.md) — avatar variants, sizes, indicators
- [icon-shapes.md](icon-shapes.md) — icon containers

### Complex Components
- [accordion.md](accordion.md) — accordion variants
- [dropdown.md](dropdown.md) — dropdown menus
- [modals.md](modals.md) — modal dialogs
- [tabs.md](tabs.md) — tab navigation
- [tables.md](tables.md) — table structure
- [pagination.md](pagination.md) — pagination components
- [sidebars.md](sidebars.md) — sidebar navigation
- [radios-checkboxes-toggle.md](radios-checkboxes-toggle.md) — selection controls
- [tooltips-popovers.md](tooltips-popovers.md) — tooltips and popovers
- [content.md](content.md) — grid system, responsiveness